# Copyright (C) AB Strakt 2001-2004, All rights reserved
# Copyright (C) Jean-Paul Calderone 2008-2009, All rights reserved

"""
pyOpenSSL - A simple wrapper around the OpenSSL library
"""

__version__ = '0.9'
