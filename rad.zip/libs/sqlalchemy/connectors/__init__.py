

class Connector(object):
    pass
    
    