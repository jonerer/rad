from sqlalchemy.dialects.maxdb import base, sapdb

base.dialect = sapdb.dialect