HOST_IP = []

HOST_IP.append("192.168.0.150")
HOST_IP.append("130.236.76.114")
      
HOST_PORT = 2345

